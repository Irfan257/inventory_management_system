from django.urls import path
from . import views

urlpatterns = [
     path('', views.login, name='login'),

    path('home/', views.home, name='home'),

    path('addcustomer/', views.addCustomer, name='addCustomer'),
    path('updatecustomer/<int:pk>/',views.update_Customer,name="update_Customer"),

    path('category/', views.addCategory, name='addCategory'),
    path('updatecategory/<int:pk>/',views.update_Category,name="update_Category"),
    path('addrec/', views.addrec, name='addrec'), 
    path('activecategory/<int:pk>/',views.Active_category,name="Active_Category"),
    path('inactivecategory/<int:pk>/',views.In_Active_Category,name="In_Active_Category"),

    path('brand/', views.addBrand, name='addBrand'),
    path('updatebrand/<int:pk>/',views.update_Brand,name="update_Brand"),
    path('activebrand/<int:pk>/',views.Active_Brand,name="Active_Brand"),
    path('inactivebrand/<int:pk>/',views.In_Active_Brand,name="In_Active_Brand"),

    path('supplier/', views.addSupplier, name='addSupplier'),
    path('updatesupplier/<int:pk>/',views.updateSupplier,name="update_Supplier"),
    path('activesupplier/<int:pk>/',views.Active_Supplier,name="Active_Supplier"),
    path('inactivesupplier/<int:pk>/',views.In_Active_Supplier,name="In_Active_Supplier"),

    path('product/', views.addProduct, name='addProducts'),
    path('updateproduct/<int:pk>/',views.update_Product,name="update_Product"),
    path('activeproduct/<int:pk>/',views.Active_Product,name="Active_Product"),
    path('inactiveproduct/<int:pk>/',views.In_Active_Product,name="In_Active_Product"),

    path('purchase/', views.addPurchase, name='addPurchase'),
    path('updatePurchase/<int:pk>/',views.update_Purchase,name="update_Purchase"),
   
    path('addorders/', views.addOrders, name='addOrders'),
    path('updateorders/<int:pk>/',views.update_Orders,name="update_Orders"),
    path('deleteorders/<int:pk>/',views.deleteorders, name='deleteorders'),
   
    path('deletecustomer/<int:pk>', views.deletecustomer, name='deletecustomer'),
    path('deleteproducts/<int:pk>', views.deleteproducts, name='deleteproducts'),
    path('deletebrand/<int:pk>', views.deletebrand, name='deletebrand'),
    path('deletecategory/<int:pk>', views.deletecategory, name='deletecategory'),
    path('deleteorders/<int:pk>', views.deleteorders, name='deleteorders'),
    path('deletepurchase/<int:pk>', views.deletepurchase, name='deletepurchase'),
    path('deletesupplier/<int:pk>', views.deletesupplier, name='deletesupplier'),
   
    path('logout/', views.logout, name='logout'),
]