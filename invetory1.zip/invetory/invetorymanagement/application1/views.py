from django.shortcuts import render, redirect
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from .models import Customer, Category, Brand, Supplier, Product, Purchase, Orders
from .forms import BrandForm, ProductForm, PurchaseForm, OrdersForm, CategoryForm , CustomerForm, SupplierForm
from django.contrib.auth.models import User
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import never_cache
from django.db.models import Sum, Count,Q

# login form:

def login(request):
    if request.method =='POST':
        username = request.POST['username']
        password = request.POST['password']

        user=auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request,user)
            print("login successfully")
            return redirect('addCustomer')
        else:
            print("you provide invlalid details")
            return redirect('login')
    else:
        return render(request, 'login.html')


# logout
@login_required(login_url='login')
def logout(request):
    if request.method == 'POST':
        auth.logout(request)
        print("logged out from website")
        return redirect('login')
    


def home(request):
    # Ensure the related names are correct and models are set up properly
    products = Product.objects.filter(status=True).annotate(
        inventory_star=Sum('quantity'),
        inventory_rec=Sum('purchase__quantity'),  # Make sure the related name is 'purchase'
        inventory_shi=Sum('orders__total_item')   # Make sure the related name is 'orders'
    )

    product_list = []
    for product in products:
        inventory_star = product.inventory_star or 0 
        inventory_rec = product.inventory_rec or 0 
        inventory_shi = product.inventory_shi or 0 
        inventory_hand = inventory_star + inventory_rec - inventory_shi
        product_data = {
            'id': product.pk,
            'name': product.product_name,
            'model': product.product_model,  # fixed typo 'modal' to 'model'
            'inventory_star': inventory_star,
            'inventory_rec': inventory_rec,
            'inventory_shi': inventory_shi,
            'inventory_hand': inventory_hand
        }
        product_list.append(product_data)

    context = {'products': product_list}  # changed 'product' to 'products' for consistency

    return render(request, 'home.html', context)


    
# customer page
@login_required(login_url='login')
@never_cache
def addCustomer(request):
    customer =Customer.objects.all()
    if request.method == 'POST':
        name = request.POST['name']
        mobile = request.POST['mobile']
        balance = request.POST['balance']
        address = request.POST['address']
        data=Customer(name=name,mobile=mobile,balance=balance,address=address)
        data.save()
        return redirect('addCustomer')
    context ={'customer':customer}
    return render(request,'customer.html',context)


# deleteustomer
@login_required(login_url='login')
@never_cache
def deletecustomer(request,pk):
    deletecustomer=Customer.objects.get(id=pk)
    deletecustomer.delete()
    return redirect('addCustomer')

# update customer
@login_required(login_url='login')
@never_cache
def update_Customer(request,pk):
    customer=Customer.objects.get(id=pk)
    form = CustomerForm(instance=customer)
    if request.method =='POST':
        form =CustomerForm(request.POST,request.FILES, instance=customer)
        if form.is_valid():
            form.save()
            return redirect('addCustomer')
    context = {"form":form}
    return render(request,'updateCustomer.html',context)

#category page
@login_required(login_url='login')
@never_cache
def addCategory(request):
    category = Category.objects.all()
    context ={'category':category}
    return render(request,'category.html',context)

@login_required(login_url='login')
@never_cache
def addrec(request):
    name =request.POST.get('name')
    cate=Category(name=name)
    cate.save()
    return redirect('addCategory')

@login_required(login_url='login')
@never_cache
def deletecategory(request,pk):
    delete_category = Category.objects.get(id=pk)
    delete_category.delete()
    return redirect('addCategory')

@login_required(login_url='login')
@never_cache
def update_Category(request,pk):
    category = Category.objects.get(id=pk)
    form = CategoryForm(instance=category)
    if request.method == "POST":
        form = CategoryForm(request.POST, request.FILES, instance = category)
        if form.is_valid():
            form.save()
            return redirect('addCategory')
    context = {"form":form,}    
    return render(request,'updateCategory.html',context)

@login_required(login_url='login')
@never_cache
def Active_category(request,pk):
    Data = Category.objects.get(id=pk)
    Data.status = False
    Data.save()
    return redirect('addCategory')

@login_required(login_url='login')
@never_cache
def In_Active_Category(request,pk):
    Data=Category.objects.get(id=pk)
    Data.status = True
    Data.save()
    return redirect('addCategory')


# brand page
@login_required(login_url='login')
@never_cache
def addBrand(request):
    form = BrandForm()
    brand =Brand.objects.all()
    category = Category.objects.all()
    if request.method == 'POST':
        form = BrandForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('addBrand')
    context = {'form':form,'brand':brand,'category':category}
    return render(request,'brand.html', context)

@login_required(login_url='login')
@never_cache
def deletebrand(request,pk):
    deltbrand = Brand.objects.get(id=pk)
    deltbrand.delete()
    return redirect('addBrand')

@login_required(login_url='login')
@never_cache
def update_Brand(request,pk):
    brand = Brand.objects.get(id=pk)
    form = BrandForm(instance=brand)
    categories = Category.objects.all()
    if request.method == "POST":
        form = BrandForm(request.POST, request.FILES, instance = brand)
        if form.is_valid():
            form.save()
            return redirect('addBrand')
    context = {"form":form , "categories": categories}    
    return render(request,'updateBrand.html',context)

@login_required(login_url='login')
@never_cache
def Active_Brand(request,pk):
    Data =Brand.objects.get(id=pk)
    Data.status =False
    Data.save()
    return  redirect('addBrand')

@login_required(login_url='login')
@never_cache
def In_Active_Brand(request,pk):
    Data = Brand.objects.get(id=pk)
    Data.status = True
    Data.save()
    return  redirect('addBrand')

# supplier 
#===================================================================
@login_required(login_url='login')
@never_cache
def addSupplier(request):
    supplier = Supplier.objects.all()
    if request.method == 'POST':
        name = request.POST['name']
        mobile = request.POST['mobile']
        address = request.POST['address']
        data = Supplier(name=name,mobile=mobile,address=address)
        data.save()
        return redirect('addSupplier')
    context ={'supplier':supplier}
    return render(request,'supplier.html',context)


@login_required(login_url='login')
@never_cache
def deletesupplier(request, pk):
    deletesupplier = Supplier.objects.get(id=pk)
    deletesupplier.delete()
    return redirect('addSupplier')

@login_required(login_url='login')
@never_cache
def updateSupplier(request,pk):
    supplier = Supplier.objects.get(id=pk)
    form = SupplierForm(instance=supplier)
    if request.method == "POST":
        form = SupplierForm(request.POST, request.FILES, instance = supplier)
        if form.is_valid():
            form.save()
            return redirect('addSupplier')
    context = {"form":form}    
    return render(request,'updateSupplier.html',context)

@login_required(login_url='login')
@never_cache
def Active_Supplier(request,pk):
    Data =Supplier.objects.get(id=pk)
    Data.status =False
    Data.save()
    return  redirect('addSupplier')


@login_required(login_url='login')
@never_cache
def In_Active_Supplier(request,pk):
    Data = Supplier.objects.get(id=pk)
    Data.status = True
    Data.save()
    return  redirect('addSupplier')

# Product Page
#============================================================================================
@login_required(login_url='login')
@never_cache
def addProduct(request):
    form = ProductForm()
    category = Category.objects.all()
    brand = Brand.objects.all()
    product = Product.objects.all()
    supplier = Supplier.objects.all()
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('addProducts')
    context = {'form':form ,'product': product,'category':category,'brand':brand,'supplier':supplier}
    return render(request, 'product.html', context)

@login_required(login_url='login')
@never_cache
def deleteproducts(request, pk):
    deleteproduct = Product.objects.get(id=pk)
    deleteproduct.delete()
    return redirect('addProducts')

@login_required(login_url='login')
@never_cache
def update_Product(request,pk):
    product = Product.objects.get(id=pk)
    form = ProductForm(instance=product)
    print("update")
    if request.method == "POST":
        print("post method")
        print(request.POST)
        # form = ProductForm(request.POST, request.FILES, instance = product)
        
        Product.objects.filter(id=pk).update(
                category = request.POST.get("category"), 
                brand_name = request.POST.get("brand_name"), 
                product_name = request.POST.get("product_name"), 
                product_model = request.POST.get("product_model"), 
                description = request.POST.get("description"), 
                quantity = request.POST.get("quantity"), 
                product_price = request.POST.get("product_price"), 
                product_tax = request.POST.get("product_tax"), 
                name = request.POST.get("name"),  
            )
        print("is valid")
        # form.save()
        return redirect('addProducts')
    return redirect('addProducts')

@login_required(login_url='login')
@never_cache
def Active_Product(request,pk):
    Data =Product.objects.get(id=pk)
    Data.status =False
    Data.save()
    return  redirect('addProducts')

@login_required(login_url='login')
@never_cache
def In_Active_Product(request,pk):
    Data = Product.objects.get(id=pk)
    Data.status = True
    Data.save()
    return  redirect('addProducts')


# Purchase Page
#============================================================================================
@login_required(login_url='login')
@never_cache
def addPurchase(request):
    form = PurchaseForm()
    purchase = Purchase.objects.all()
    supplier = Supplier.objects.all()
    product = Product.objects.all()
    if request.method == 'POST':
        form = PurchaseForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('addPurchase')
    context = {'form': form, 'purchase': purchase,'supplier':supplier,'product':product}
    return render(request, 'purchase.html', context)

@login_required(login_url='login')
@never_cache
def deletepurchase(request, pk):
    deltpur = Purchase.objects.get(id=pk)
    deltpur.delete()
    return redirect('addPurchase')

@login_required(login_url='login')
@never_cache
def update_Purchase(request,pk):
    purchase = Purchase.objects.get(id=pk)
    form = PurchaseForm(instance=purchase)
    print("update")
    if request.method == "POST":
        print("post method")
        print(request.POST)


        # form = PurchaseForm(request.POST, request.FILES, instance = purchase)
        Purchase.objects.filter(id=pk).update(
            product_name = request.POST.get("product_name"),
            quantity = request.POST.get ("quantity"),
            name = request.POST.get("name"),
        )
        print("is valid")
        return redirect ('addPurchase')
               
    return redirect('addPurchase')

# Orders Page
#============================================================================================
@login_required(login_url='login')
@never_cache
def addOrders(request):
    form = OrdersForm()
    orders = Orders.objects.all()
    product = Product.objects.all()
    customer = Customer.objects.all()
    if request.method == 'POST':
        form = OrdersForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('addOrders')
    context = {'orders': orders, 'form':form,'product':product,'customer':customer}
    return render(request, 'orders.html', context)


@login_required(login_url='login')
@never_cache
def deleteorders(request, pk):
    deleteorders = Orders.objects.get(id=pk)
    deleteorders.delete()
    return redirect('addOrders')


@login_required(login_url='login')
@never_cache
def update_Orders(request,pk):
    orders = Orders.objects.get(id=pk)
    form = OrdersForm(instance=Orders)
    print("update")
    if request.method == "POST":
        print("post method")
        print(request.POST)


        # form = PurchaseForm(request.POST, request.FILES, instance = purchase)
        Orders.objects.filter(id=pk).update(
            product_name = request.POST.get("product_name"),
            total_item = request.POST.get ("total_item"),
            name = request.POST.get("name"),
        )
        print("is valid")
        return redirect ('addOrders')
               
    return redirect('addOrders')
    




