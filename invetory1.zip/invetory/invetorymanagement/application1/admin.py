from django.contrib import admin
from .models import Customer, Category, Brand, Supplier, Product, Purchase, Orders

admin.site.register(Customer)
admin.site.register(Category)
admin.site.register(Brand)
admin.site.register(Supplier)
admin.site.register(Product)
admin.site.register(Purchase)
admin.site.register(Orders)

